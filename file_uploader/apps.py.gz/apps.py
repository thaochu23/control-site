from django.apps import AppConfig


class FileUploaderConfig(AppConfig):
    name = 'file_uploader'
